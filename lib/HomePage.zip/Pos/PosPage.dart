import 'package:flutter/material.dart';
import 'package:pos/Pos/CartProvider.dart';
import 'package:pos/Pos/ProductModel.dart';
import 'package:pos/Pos/ProductController.dart';
import 'package:provider/provider.dart';
import '../utils/Drawer.dart';

class PosPage extends StatefulWidget {
  @override
  _PosPageState createState() => _PosPageState();
}

class _PosPageState extends State<PosPage> {
  final TextEditingController _productSearchController =
      TextEditingController();
  List<Product> _filteredProducts = [];

  void _filterProducts(String searchTerm) async {
    if (searchTerm.isEmpty) {
      _filteredProducts =
          []; //fetchProducts(''); // Show all products on empty search
    } else if (searchTerm.length >= 3) {
      final productsData = await ProductController().fetchProducts(searchTerm);
      _filteredProducts = productsData
          .where((product) => product.productName
              .toLowerCase()
              .contains(searchTerm.toLowerCase()))
          .toList();
    }
    setState(() {}); // Update UI with filtered products
  }

  void _addToCartAndClearResults(Product product) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${product.productName} added to cart'),
        duration: Duration(seconds: 2),
      ),
    );
    setState(() {
      _filteredProducts = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    final selectedCartItems = Provider.of<CartProvider>(context).cartItems;

    return Scaffold(
      drawer: MyDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(width: 10),
            Autocomplete<String>(
              optionsBuilder: (TextEditingValue textEditingValue) {
                if (textEditingValue.text.isEmpty) {
                  // Return an empty list when there's no text in the search field
                  return <String>[];
                } else if (textEditingValue.text.length >= 3) {
                  // Fetch products based on the search term
                  // _productSearchController.clear();
                  return ProductController()
                      .fetchProducts(textEditingValue.text)
                      .then((productsData) {
                    return productsData
                        .where((product) => product.productName
                            .toLowerCase()
                            .contains(textEditingValue.text.toLowerCase()))
                        .map((product) => product.productName)
                        .toList();
                  });
                }
                // Return an empty list when the search term is less than 3 characters
                return <String>[];
              },
              onSelected: (String selectedProduct) {
                // Find the selected product from the list of filtered products
                Product selectedProductObj = _filteredProducts.firstWhere(
                  (product) => product.productName == selectedProduct,
                  orElse: () => Product(
                      productId: 0,
                      productStockId: '',
                      outletId: '',
                      productType: '',
                      productName: '',
                      productNativeName: '',
                      productCode: '',
                      categoryId: '',
                      barcodeSymbology: '',
                      minOrderQty: '',
                      costPrice: 0,
                      depoPrice: 0,
                      mrpPrice: 0,
                      taxMethod: 0,
                      productTax: 0,
                      measuringUnit: 0,
                      weight: 0,
                      itemDiscount: 0,
                      discount: 0,
                      tax: 0,
                      quantity: '',
                      stockQuantity: '',
                      expiresDate: '',
                      disArray: {},
                      newPrice: 0), // Default empty product
                  // Return null if product is not found
                );

                // Check if the selected product is found
                if (selectedProductObj != null) {
                  // Add the selected product to the cart and show a message
                  _addToCartAndClearResults(selectedProductObj);
                  Provider.of<CartProvider>(context, listen: false)
                      .addToCart(selectedProductObj);
                } else {
                  // Handle case when product is not found
                  print('Product not found');
                  // You can show a message or perform any other action here
                }

                // Clear the search field after selecting a product or if no product is found
                _productSearchController.clear();
              },
              fieldViewBuilder: (BuildContext context,
                  TextEditingController fieldTextEditingController,
                  FocusNode fieldFocusNode,
                  VoidCallback onFieldSubmitted) {
                return TextField(
                  controller: fieldTextEditingController,
                  focusNode: fieldFocusNode,
                  onChanged: (String value) {
                    // Update the autocomplete options when the text field value changes
                    _filterProducts(value);
                  },
                  decoration: InputDecoration(
                    hintText: 'Search Products...',
                    prefixIcon: Icon(Icons.search),
                    suffixIcon: IconButton(
                      icon: Icon(Icons.barcode_reader),
                      onPressed: () {
                        // Handle barcode icon press here
                      },
                    ),
                  ),
                );
              },
            ),
            // CartItemList(),
            Container(
              height: 400, // Adjust the height as needed
              child: ListView.builder(
                itemCount: selectedCartItems.length,
                itemBuilder: (context, index) {
                  final cartItem = selectedCartItems[index];
                  return Container(
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: Colors.green,
                          width: 1.0,
                        ), // Green 1px bottom border
                      ),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              flex: 11,
                              child: Container(
                                color: Colors.white,
                                height: 80, // Adjust the height as needed

                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Name ${cartItem.product.productName}',
                                      style: TextStyle(
                                        fontSize: 11,
                                      ), // Adjust the font size of the item name
                                    ),
                                    SizedBox(height: 5),
                                    Container(
                                      height:
                                          40, // Set the height of the container
                                      width:
                                          100, // Set the width of the container
                                      child: TextField(
                                        keyboardType: TextInputType.number,
                                        onChanged: (value) {
                                          setState(() {
                                            final newPrice =
                                                double.tryParse(value) ?? 0;
                                            // Update the price directly in the cartItem
                                            cartItem.product.newPrice =
                                                newPrice;
                                            // Call the method in CartProvider to update the item's price and recalculate netAmount
                                            Provider.of<CartProvider>(
                                              context,
                                              listen: false,
                                            ).updateCartItemPrice(
                                              cartItem,
                                              newPrice,
                                            );
                                          });
                                        },
                                        decoration: InputDecoration(
                                          labelText: 'Price',
                                          hintText: 'Enter price',
                                          border: OutlineInputBorder(),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 4,
                              child: Container(
                                height: 80, // Adjust the height as needed
                                child: Center(
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            InkWell(
                                              onTap: () {
                                                setState(() {
                                                  if (cartItem.qty > 0) {
                                                    cartItem.qty--;
                                                    // Call method to update cart quantity
                                                    Provider.of<CartProvider>(
                                                      context,
                                                      listen: false,
                                                    ).updateCartItemQuantity(
                                                      cartItem,
                                                      cartItem.qty,
                                                    );
                                                  }
                                                });
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                    color: Colors.green,
                                                  ), // Green border
                                                ),
                                                child: Icon(
                                                  Icons.remove,
                                                  color: Colors.red,
                                                  size: 9,
                                                ), // Set the icon color to red and adjust size
                                                padding: EdgeInsets.all(
                                                  6,
                                                ), // Adjust padding as needed
                                              ),
                                            ),
                                            SizedBox(width: 5),
                                            Text(
                                              'Qty: ${cartItem.qty}',
                                              style: TextStyle(
                                                fontSize: 12,
                                              ), // Adjust the font size of the quantity text
                                            ),
                                            SizedBox(width: 5),
                                            InkWell(
                                              onTap: () {
                                                setState(() {
                                                  cartItem.qty++;
                                                  // Call method to update cart quantity
                                                  Provider.of<CartProvider>(
                                                    context,
                                                    listen: false,
                                                  ).updateCartItemQuantity(
                                                    cartItem,
                                                    cartItem.qty,
                                                  );
                                                });
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                    color: Colors.green,
                                                  ), // Green border
                                                ),
                                                child: Icon(
                                                  Icons.add,
                                                  color: Colors.green,
                                                  size: 9,
                                                ), // Set the icon color to green and adjust size
                                                padding: EdgeInsets.all(
                                                  6,
                                                ), // Adjust padding as needed
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 10),
                                        Text(
                                          'Subtotal: ${double.tryParse(cartItem.subtotal.toString())}',
                                          style: TextStyle(
                                            fontSize: 12,
                                          ), // Adjust the font size of the subtotal text
                                        ),
                                      ]),
                                ),
                              ),
                            ),
                          ],
                        ),
                        // You can add more widgets here as needed
                      ],
                    ),
                  );
                },
              ),
            ),

            // price and item name will be left side and qty and subtotal right site , left side 85% and right 15% spach

            // Expanded(
            //   child: ListView.builder(
            //     itemCount: selectedCartItems.length,
            //     itemBuilder: (context, index) {
            //       final cartItem = selectedCartItems[index];
            //       return Padding(
            //         padding:
            //             EdgeInsets.all(2.0), // Add padding of 5px on all sides
            //         child: ListTile(
            //           title: Text('Name ${cartItem.product.productCode}'),
            //           subtitle: Row(
            //             children: [
            //               Row(
            //                 children: [
            //                   IconButton(
            //                     icon: Icon(Icons.remove,
            //                         color: Colors
            //                             .red), // Set the icon color to red
            //                     onPressed: () {
            //                       setState(() {
            //                         if (cartItem.qty > 0) {
            //                           cartItem.qty--;
            //                           // Call method to update cart quantity
            //                           Provider.of<CartProvider>(context,
            //                                   listen: false)
            //                               .updateCartItemQuantity(
            //                                   cartItem, cartItem.qty);
            //                         }
            //                       });
            //                     },
            //                   ),
            //                   Text('Qty: ${cartItem.qty}'),
            //                   IconButton(
            //                     icon: Icon(Icons.add,
            //                         color: Colors
            //                             .green), // Set the icon color to green
            //                     iconSize: 20, // Set the size of the icon
            //                     onPressed: () {
            //                       setState(() {
            //                         cartItem.qty++;
            //                         // Call method to update cart quantity
            //                         Provider.of<CartProvider>(context,
            //                                 listen: false)
            //                             .updateCartItemQuantity(
            //                                 cartItem, cartItem.qty);
            //                       });
            //                     },
            //                   ),
            //                 ],
            //               ),
            //               SizedBox(width: 10),
            //               Expanded(
            //                 child: Container(
            //                   height: 35, // Set the desired height
            //                   width: 50, // Set the desired width
            //                   child: TextField(
            //                     keyboardType: TextInputType.number,
            //                     onChanged: (value) {
            //                       setState(() {
            //                         final newPrice =
            //                             double.tryParse(value) ?? 0;
            //                         // Update the price directly in the cartItem
            //                         cartItem.product.newPrice = newPrice;
            //                         // Call the method in CartProvider to update the item's price and recalculate netAmount
            //                         Provider.of<CartProvider>(context,
            //                                 listen: false)
            //                             .updateCartItemPrice(
            //                                 cartItem, newPrice);
            //                       });
            //                     },
            //                     decoration: InputDecoration(
            //                       labelText: 'Price',
            //                       hintText: 'Enter price',
            //                       border: OutlineInputBorder(),
            //                     ),
            //                   ),
            //                 ),
            //               ),
            //               SizedBox(width: 10),
            //               Text(
            //                 'Subtotal: ${double.tryParse(cartItem.subtotal.toString())}',
            //                 style: TextStyle(
            //                     fontSize:
            //                         12), // Adjust the font size of the subtotal text
            //               ),
            //             ],
            //           ),
            //           tileColor: Colors.lightGreenAccent,
            //         ),
            //       );
            //     },
            //   ),
            // ),

            // Expanded(
            //   child: ListView.builder(
            //     itemCount: selectedCartItems.length,
            //     itemBuilder: (context, index) {
            //       final cartItem = selectedCartItems[index];
            //       return Container(
            //         decoration: BoxDecoration(
            //           border: Border(
            //             bottom: BorderSide(
            //               color: Colors.green,
            //               width: 1.0,
            //             ), // Green 1px bottom border
            //           ),
            //         ),
            //         child: Padding(
            //           padding: EdgeInsets.all(
            //               2.0), // Add padding of 5px on all sides
            //           child: ListTile(
            //             title: Text(
            //               'Name ${cartItem.product.productCode}',
            //               style: TextStyle(
            //                   fontSize:
            //                       12), // Adjust the font size of the item name
            //             ),
            //             subtitle: Row(
            //               children: [
            //                 Row(
            //                   children: [
            //                     InkWell(
            //                       onTap: () {
            //                         setState(() {
            //                           if (cartItem.qty > 0) {
            //                             cartItem.qty--;
            //                             // Call method to update cart quantity
            //                             Provider.of<CartProvider>(context,
            //                                     listen: false)
            //                                 .updateCartItemQuantity(
            //                                     cartItem, cartItem.qty);
            //                           }
            //                         });
            //                       },
            //                       child: Container(
            //                         decoration: BoxDecoration(
            //                           shape: BoxShape.circle,
            //                           border: Border.all(
            //                             color: Colors.green,
            //                           ), // Green border
            //                         ),
            //                         child: Icon(
            //                           Icons.remove,
            //                           color: Colors.red,
            //                           size: 9,
            //                         ), // Set the icon color to red and adjust size
            //                         padding: EdgeInsets.all(
            //                             6), // Adjust padding as needed
            //                       ),
            //                     ),
            //                     SizedBox(width: 5),
            //                     Text(
            //                       'Qty: ${cartItem.qty}',
            //                       style: TextStyle(
            //                           fontSize:
            //                               12), // Adjust the font size of the quantity text
            //                     ),
            //                     SizedBox(width: 5),
            //                     InkWell(
            //                       onTap: () {
            //                         setState(() {
            //                           cartItem.qty++;
            //                           // Call method to update cart quantity
            //                           Provider.of<CartProvider>(context,
            //                                   listen: false)
            //                               .updateCartItemQuantity(
            //                                   cartItem, cartItem.qty);
            //                         });
            //                       },
            //                       child: Container(
            //                         decoration: BoxDecoration(
            //                           shape: BoxShape.circle,
            //                           border: Border.all(
            //                             color: Colors.green,
            //                           ), // Green border
            //                         ),
            //                         child: Icon(
            //                           Icons.add,
            //                           color: Colors.green,
            //                           size: 9,
            //                         ), // Set the icon color to green and adjust size
            //                         padding: EdgeInsets.all(
            //                             6), // Adjust padding as needed
            //                       ),
            //                     ),
            //                   ],
            //                 ),
            //                 SizedBox(width: 10),
            //                 Expanded(
            //                   child: Container(
            //                     height: 35, // Set the desired height
            //                     width: 50, // Set the desired width
            //                     child: TextField(
            //                       keyboardType: TextInputType.number,
            //                       onChanged: (value) {
            //                         setState(() {
            //                           final newPrice =
            //                               double.tryParse(value) ?? 0;
            //                           // Update the price directly in the cartItem
            //                           cartItem.product.newPrice = newPrice;
            //                           // Call the method in CartProvider to update the item's price and recalculate netAmount
            //                           Provider.of<CartProvider>(context,
            //                                   listen: false)
            //                               .updateCartItemPrice(
            //                                   cartItem, newPrice);
            //                         });
            //                       },
            //                       decoration: InputDecoration(
            //                         labelText: 'Price',
            //                         hintText: 'Enter price',
            //                         border: OutlineInputBorder(),
            //                       ),
            //                     ),
            //                   ),
            //                 ),
            //                 SizedBox(width: 10),
            //                 Text(
            //                   'Subtotal: ${double.tryParse(cartItem.subtotal.toString())}',
            //                   style: TextStyle(
            //                     fontSize: 12,
            //                   ), // Adjust the font size of the subtotal text
            //                 ),
            //               ],
            //             ),
            //             tileColor: Colors.white,
            //           ),
            //         ),
            //       );
            //     },
            //   ),
            // ),
            // Can change re-desing
            // i need to qty and subtotal right side qty top and subtotal will be bottom position

            // Please add bd color white and each item separator 1px green color

            // Expanded(
            //   child: ListView.builder(
            //     itemCount: selectedCartItems.length,
            //     itemBuilder: (context, index) {
            //       final cartItem = selectedCartItems[index];
            //       return Padding(
            //         padding:
            //             EdgeInsets.all(2.0), // Add padding of 5px on all sides
            //         child: ListTile(
            //           title: Text('Name ${cartItem.product.productCode}'),
            //           subtitle: Row(
            //             children: [
            //               Text('Qty: ${cartItem.qty}'),
            //               SizedBox(width: 10),
            //               Expanded(
            //                 child: Container(
            //                   height: 35, // Set the desired height
            //                   width: 50, // Set the desired width
            //                   child: TextField(
            //                     keyboardType: TextInputType.number,
            //                     onChanged: (value) {
            //                       setState(() {
            //                         final newPrice =
            //                             double.tryParse(value) ?? 0;
            //                         // Update the price directly in the cartItem
            //                         cartItem.product.newPrice = newPrice;
            //                         // Call the method in CartProvider to update the item's price and recalculate netAmount
            //                         Provider.of<CartProvider>(context,
            //                                 listen: false)
            //                             .updateCartItemPrice(
            //                                 cartItem, newPrice);
            //                       });
            //                     },
            //                     decoration: InputDecoration(
            //                       labelText: 'Price',
            //                       hintText: 'Enter price',
            //                       border: OutlineInputBorder(),
            //                     ),
            //                   ),
            //                 ),
            //               ),
            //               SizedBox(width: 10),
            //               Text(
            //                   'Subtotal: ${double.tryParse(cartItem.product.newPrice.toString())}'),
            //             ],
            //           ),
            //           tileColor: Colors.lightGreenAccent,
            //         ),
            //       );
            //     },
            //   ),
            // ),
            Center(
              child: Consumer<CartProvider>(
                builder: (context, cartProvider, child) {
                  return Text(
                    'Net Amount: ${cartProvider.netAmount.toString()}',
                    style: TextStyle(fontSize: 24),
                  );
                },
              ),
            ),
            // Cart item list with quantity and subtotal

            ElevatedButton(
              onPressed: () {
                print('Order submitted! Net amount: Tk  ');
              },
              child: Text('Submit Order'),
            ),
          ],
        ),
      ),
    );
  }
}
